import pandas as pd

# Load the Excel file
file_path = './variable_setcall_new.xlsx'
df = pd.read_excel(file_path, sheet_name='10sub100s')

for i in range(0,100):
    df_new = df[df["set_id"]==i].copy()
    # Convert the timestamp to nanoseconds
    df_new['exit_timestamp_in_nanoseconds'] = pd.to_datetime(df_new['databroker_exit_timestamp']).view('int64')
    df_new['enter_timestamp_in_nanoseconds'] = pd.to_datetime(df_new['databroker_enter_timestamp']).view('int64')
    df_new['process_time_ns'] = df_new['exit_timestamp_in_nanoseconds'] -  df_new.iloc[0]['enter_timestamp_in_nanoseconds']

    df_new['process_time_ms'] = df_new['process_time_ns'] / 1000000

    result = (df_new['process_time_ns'].max() - df_new['process_time_ns'].min()) /  round((df_new['process_time_ns'].count() ** 0.5)+1)
    # print(df_new['process_time_ns'].max(), df_new['process_time_ns'].min(), df_new['process_time_ns'].count(), round((df_new['process_time_ns'].count() ** 0.5)+1))

    bin_width = result / 1000000

    mean = df_new['process_time_ms'].mean()

    # Calculate standard deviation
    std_dev = df_new['process_time_ms'].std()

    # Calculate variance
    variance = df_new['process_time_ms'].var()

    # Create a new DataFrame for the stats
    stats_df = pd.DataFrame({
        'Stats': ['bin_width' ,'Mean', 'Standard Deviation', 'Variance'],
        'Values': [bin_width, mean, std_dev, variance]
    })

    result_df = pd.concat([df_new,stats_df], ignore_index=True)
    with pd.ExcelWriter('./variable_setcall_new.xlsx', mode="a", engine="openpyxl") as writer:
     # Write the original DataFrame to a sheet named 'OriginalData'
     sheet_name = 'Sheet_'+str(i)
     result_df.to_excel(writer, sheet_name=sheet_name, index=False)
