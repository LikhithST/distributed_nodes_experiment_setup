import sqlite3
import csv

def execute_sql():
    try:
        # Connect to the SQLite database
        connection = sqlite3.connect('ghz.db')
        cursor = connection.cursor()
        
        # Execute provided query
        select_query = '''
        SELECT *
        FROM details
        WHERE request_id = '10sub100s' 
        ORDER BY set_id ASC
        '''
        cursor.execute(select_query)
        
        # Fetch column names
        column_names = [description[0] for description in cursor.description]
        
        # Fetch and process the results
        rows = cursor.fetchall()
        processed_rows = []
        for row in rows:
            processed_row = tuple("" if "0001-01-01 00:00:00+00:00" in str(value) else value for value in row)
            processed_rows.append(processed_row)
        
        # Print the results
        print("Query Results:")
        print(column_names)  # Print column names
        for row in processed_rows:
            print(row)
        
        # Write results to a CSV file
        with open('query_results.csv', 'w', newline='') as csvfile:
            csvwriter = csv.writer(csvfile)
            csvwriter.writerow(column_names)  # Write column names
            csvwriter.writerows(processed_rows)  # Write data rows
    
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")
    
    finally:
        if connection:
            connection.close()

if __name__ == "__main__":
    execute_sql()
