from datetime import datetime, timedelta

def calculate_latency_microseconds(start_time_str, additional_time_ns, time_diffs_ns, additional_nanoseconds):
    # Convert the start time to a datetime object
    start_time = datetime.fromisoformat(start_time_str)
    
    # Convert the single additional time in nanoseconds to timedelta
    total_microseconds = additional_time_ns / 1000
    additional_timedelta = timedelta(microseconds=total_microseconds)
    
    # Add the additional time to the start time
    new_time = start_time + additional_timedelta
    
    # Add the time differences provided in nanoseconds
    for diff in time_diffs_ns:
        time1 = datetime.fromisoformat(diff[0])
        time2 = datetime.fromisoformat(diff[1])
        time_difference = time1 - time2
        new_time += time_difference
    
    # Convert additional nanoseconds to microseconds and add to the new time
    microseconds_to_add = additional_nanoseconds / 1000
    final_time = new_time + timedelta(microseconds=microseconds_to_add)
    
    # Calculate the latency
    latency = final_time - start_time
    
    # Convert latency to microseconds
    latency_microseconds = latency.total_seconds() * 1_000_000
    
    return latency_microseconds

# Example usage
start_time_str = '2024-06-10 10:36:14.12611859+02:00'
additional_time_ns = 865817  # Converted to nanoseconds for the sum of additional times
time_diffs_ns = [
    ( '2024-06-10 10:36:14.127443174+02:00',  '2024-06-10 10:36:14.126984407+02:00')
]
additional_nanoseconds = 246957

latency = calculate_latency_microseconds(start_time_str, additional_time_ns, time_diffs_ns, additional_nanoseconds)
print(latency)
