## Steps to follow

1. create a xlsx file you want the save data in. Here create 'latency_and_mean_stats.xlsx' file

2. python3 sqlite-latency-extractor.py